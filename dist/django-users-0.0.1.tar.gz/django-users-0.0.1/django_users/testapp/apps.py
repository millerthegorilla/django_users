from django.apps import AppConfig


class TestAppConfig(AppConfig):
    name = "django_users.testapp"
    verbose_name = "TestApp"
