from django.apps import AppConfig


class DjangoUsersTestAppConfig(AppConfig):
    name = "django_users.tests.djangouserstestapp"
    verbose_name = "DjangoUsersTestAppConfig"
