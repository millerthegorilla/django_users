from django.apps import AppConfig


class TestAppConfig(AppConfig):
    name = "django_users.tests.testapp"
    verbose_name = "TestApp"
